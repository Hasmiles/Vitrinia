<?php

namespace App\Http\Controllers;

use App\Models\Seller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SellerController extends Controller
{
    public function index()
    {
        $user = User::with('seller')->find(Auth::user()->id);
        $profile = [
            "id" => $user->id,
            "shop_name" => $user->seller->shop_name,
            "phone" => $user->seller->phone,
            "iban" => $user->seller->iban,
            "owner_name" => $user->name,
            "logo" => 'sellers/' . $user->seller->logo,
            "is_completed" => $user->seller->is_completed == 0 ? false : true,
            "verification_code" => null,
            "push_token" => $user->fcm_token
        ];
        return response()->json($profile, 200);
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $user = User::find(Auth::user()->id);
        $user->name = $request->owner_name;
        $user->save();
        $seller = Seller::where('user_id', $user->id)->first();
        $seller->shop_name = $request->shop_name;
        $seller->phone = $request->phone;
        $seller->iban = $request->iban;
        $customFileName = $seller->logo;
        if ($request->hasFile('image')){
            $image = $request->file('image');
            $path = $image->store('sellers', 'public');
            $customFileName = basename($path);
        }
        $seller->logo = $customFileName;
        $seller->save();
        $profile = [
            "id" => $user->id,
            "shop_name" => $user->seller->shop_name,
            "phone" => $user->seller->phone,
            "iban" => $user->seller->iban,
            "owner_name" => $user->name,
            "logo" => 'sellers/' . $user->seller->logo,
            "is_completed" => $user->seller->is_completed == 0 ? false : true,
            "verification_code" => null,
            "push_token" => $user->fcm_token
        ];
        return response()->json($profile, 200);

    }

    public function show(string $id)
    {
        //
    }

    public function edit(string $id)
    {
        //
    }

    public function update(Request $request, string $id)
    {
        //
    }

    public function destroy(string $id)
    {
        //
    }
}
