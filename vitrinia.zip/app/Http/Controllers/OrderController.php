<?php

namespace App\Http\Controllers;

use App\Http\Resources\OrderForCustomerResource;
use App\Http\Resources\OrderResource;
use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderLog;
use App\Models\OrderProduct;
use App\Models\OrderProductOption;
use App\Models\Product;
use App\Models\SubOption;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class OrderController extends Controller
{
    public function index()
    {
        $user = User::find(Auth::user()->id);
        $orders = Order::where('seller_id', $user->id)
            ->orderBy('created_at', 'desc')
            ->with(['products.product.subOptions', 'customer', 'products.option'])
            ->get();
        return response()->json(['orders' => OrderResource::collection($orders)], 200);
    }

    public function store(Request $request)
    {
        $user = User::find(Auth::user()->id);
        $request->validate([
            'product_id' => 'required|exists:products,id',
            'payment_method' => 'required|string'
        ]);
        $productId = $request->input('product_id');
        $type = $request->payment_method == 'iban' ? 1 : 2;
        $product = Product::find($productId);
        if (!$product) {
            return response()->json(['hata' => 'Ürün yok'], 404);
        }
        if (is_null($product->stock) && $product->stock < 0) {
            return response()->json(['hata' => 'Stokta kalmadı'], 404);
        }

        $status = 1;
        $stat_ids = [1];
        if ($type == 2) {
            $status = 5;
            $stat_ids = [5];
        }

        $kisaKod = Str::random(5);  // Güvenlik zaafiyetlerini bi araştır.

        $order = Order::create([
            'seller_id' => $user->id,
            'customer_id' => 0,
            'type' => $type,
            'status' => $status,
            'short_code' => $kisaKod
        ]);
        OrderProduct::create([
            'order_id' => $order->id,
            'product_id' => $product->id,
            'quantity' => 1,
            'price' => $product->price * 1,
            'active' => 1
        ]);
        // $orderLog = OrderLog::create([
        //     'order_id' => $order->id,
        //     'status' => $status
        // ]);
        $order->logs()->attach($stat_ids);
        $product->decrement('stock');
        $order->load(['products.product.subOptions', 'customer', 'products.option']);
        return response()->json([
            'mesaj' => 'Sipariş oluşturuldu!',
            'link' => "https://butikasistanim.vercel.app/s/{$kisaKod}",
            'order' => new OrderResource($order),
        ], 201);
    }

    public function edit(Order $order) {}

    public function update(Request $request, string $short_code)
    {
        $request->validate([
            'customer_name' => 'required|string|max:255',
            'customer_phone' => 'required|string|max:50',
            'customer_address' => 'required|string|max:255',
            'customer_city' => 'required|string|max:100',
            'customer_town' => 'required|string|max:100',
        ]);
        $order = Order::where('short_code', $short_code)->first();
        if (is_null($order)) {
            return response()->json([
                    'success' => false,
                    'message' => 'Böyle bir sipariş yok'
                ],400);
        }
        $customer = Customer::create([
            'fullname' => $request->customer_name,
            'phone' => $request->customer_phone,
            'city' => $request->customer_city ?? '',
            'town' => $request->customer_town ?? '',
            'address' => $request->customer_address,
            'note' => $request->note ?? ''
        ]);

        $order->customer_id = $customer->id;
        $order->status = 2;
        $order->logs()->attach(2);
        $values = array_values($request->selected_options);
        if ($values) {
            $sub_options = SubOption::whereIn('value', $values)->pluck('id');
            $order_product_id = OrderProduct::where('order_id', $order->id)->first()->id;
            foreach ($sub_options as $id) {
                OrderProductOption::create([
                    'order_product_id' => $order_product_id,
                    'option_id' => $id
                ]);
            }
        }

        $order->save();
        $order->load(['products.product.subOptions', 'customer', 'seller', 'products.option']);
        return response()->json([
            'message' => 'Sipariş oluşturuldu!',
            'order' => new OrderForCustomerResource($order),
        ], 201);
    }

    public function getOrderDetailsForCustomer(string $short_code){
        $orders = Order::where('short_code', $short_code)
            ->orderBy('created_at', 'desc')
            ->with(['products.product.subOptions', 'customer', 'seller', 'products.option'])
            ->get();
        return response()->json(['orders' => OrderForCustomerResource::collection($orders)], 200);
    }

    public function changeSituationForOrder(Request $request, Order $order)
    {
        $request->validate([
            'status' => 'required|integer',
        ]);
        $type = $request->status;
        $order->type = $type;
        $order->logs()->attach($type);
        $order->save;
        return response()->json([
            'message' => 'Sipariş durumu değiştirildi!',
            'order' => $order,
        ], 201);
    }

    public function destroy(Order $order)
    {
        $order->delete();
        return response()->json([
            'success' => true,
            'message' => 'Sipariş silindi'
        ], 200);
    }
}
