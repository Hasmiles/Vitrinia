<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Seller;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\JsonResponse;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $request->validate([
            'owner_name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string'],
        ]);
        $user = User::create([
            'name' => $request->owner_name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);
        $customFileName = '';
        if ($request->hasFile('image')){
            $image = $request->file('image');
            $path = $image->store('sellers', 'public');
            $customFileName = basename($path);
        }
        Seller::create([
            'user_id' => $user->id,
            'shop_name' => $request->shop_name,
            'logo' => $customFileName,
            'phone' => $request->phone,
            'iban' => $request->iban
        ]);
        return response()->json([
            'success' => true,
            'user' => $user
        ], 200);
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);
        if (Auth::attempt($credentials)) {
            $user = User::find(Auth::user()->id);
            $access_token = $user->createToken('auth_token')->plainTextToken;
            return response()->json([
                'success' => true,
                'access_token' => $access_token,
            ]);
        }
        return response()->json(['message' => 'Giriş başarısız'], 401);
    }

    public function user()
    {
        if (Auth::check()) {
            $user = User::find(Auth::user()->id);
            return response()->json([
                'id' => $user->id,
                'uid' => $user->uid,
            ], 200);
        }
        return response()->json([], 401);
    }

    public function logout(Request $request): JsonResponse
    {
        $request->user()->currentAccessToken()->delete();
        return response()->json([
            'success' => true,
            'message' => 'Logout successfully.',
        ], 401);
    }
}
