<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'seller_id',
        'customer_id',
        'type',
        'status',
        'short_code'
    ];


    public function seller()
    {
        return $this->belongsTo(User::class, 'seller_id', 'id'); 
    }

    public function logs(){
        return $this->belongsToMany(Status::class, 'order_logs', 'order_id', 'status')->withTimestamps();
    }

    public function products()
    {
        return $this->hasMany(OrderProduct::class, 'order_id', 'id');
    }

    public function customer(){
        return $this->belongsTo(Customer::class, 'customer_id');
    }
}
