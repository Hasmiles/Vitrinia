<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\SellerController;
use App\Models\User;

Route::prefix('auth')->group(function () {
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/register', [AuthController::class, 'register']);
});


// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:sanctum');

Route::middleware('auth:sanctum')->group(function () {
    Route::prefix('auth')->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/user', [AuthController::class, 'user']);
    });
    Route::resource('sellers/me', SellerController::class);
    Route::resource('products', ProductController::class);
    Route::delete('/products', [ProductController::class, 'destroy']);
    Route::patch('/orders/{id}/status', [OrderController::class, 'changeSituationForOrder']);
    
    Route::get('/orders/{id}/label', [OrderController::class, 'createLabel']); // Yapılacak
    Route::get('/sellers/report', [SellerController::class, 'reportForSeller']); // Yapılacak
    Route::get('/sellers/dashboard', [SellerController::class, 'dashboard']); // Yapılacak
    Route::resource('orders', OrderController::class);
});

Route::get('/orders/public/{kisa_kod}', [OrderController::class, 'getOrderDetailsForCustomer']);

